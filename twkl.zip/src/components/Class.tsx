import React from "react";

// CLASS IMAGES
import playgroup from "../assets/PIC1.png";
import prekg from "../assets/PIC2.png";
import juniorkg from "../assets/PIC3.png";
import seniorkg from "../assets/PIC4.png";

// DECOR IMAGES
import rainbow from "../assets/RAINBOW.png";
import star from "../assets/STAR.png";
import aero from "../assets/AERO2.png";
import flower from "../assets/blue-cloud-with-star.png";
import separator from "../assets/WHITE-SEPERATOR.png";

// BACKGROUND PATTERN
import bgPattern from "../assets/ORANGE-BGM.jpg";

const classes = [
  {
    title: "Playgroup",
    img: playgroup,
    desc: "A joyful introduction to school where little ones learn through play and fun activities. We focus on social skills, communication, and cognitive development.",
  },
  {
    title: "Pre kg",
    img: prekg,
    desc: "Children explore letters, numbers, colors, and shapes through engaging stories, songs, and hands-on activities guided by teachers.",
  },
  {
    title: "Junior kg",
    img: juniorkg,
    desc: "We strengthen literacy and numeracy skills with interactive lessons, helping children build confidence and creativity.",
  },
  {
    title: "Senior kg",
    img: seniorkg,
    desc: "Children build a strong foundation in reading, writing, and math, preparing confidently for primary school.",
  },
];

const Classes = () => {
  return (
    <div
      className="relative w-full overflow-hidden py-20"
      style={{
        backgroundImage: `url(${bgPattern})`,
        backgroundRepeat: "repeat",
        backgroundSize: "1750px",
      }}
    >
      {/* TOP DECORATIONS */}
      <img
        src={aero}
        alt="aero"
        className="absolute top-10 left-44 w-20 md:w-48"
      />
      <img
        src={star}
        alt="star"
        className="absolute top-8 right-[33%] w-24"
      />
      <img
        src={flower}
        alt="flower"
        className="absolute top-20 right-24 w-40"
      />

      {/* TITLE */}
      <h1 className="text-center text-white text-4xl md:text-6xl font-bold mb-36 tracking-wide">
        CLASSES
      </h1>

      {/* CARDS */}
      <div className="relative max-w-7xl mx-auto px-6 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-14 z-10 -mt-6 md:-mt-10">        {classes.map((item, index) => (
          <div
            key={index}
            className="bg-gray-100 rounded-[40px] p-3 text-center shadow-xl hover:scale-105 transition duration-300"
          >
            {/* IMAGE FRAME */}
            <div className=" rounded-[30px] p-1 mb-4">
              <img
                src={item.img}
                alt={item.title}
                className="rounded-[25px] w-full h-[180px] object-cover"
              />
            </div>

            {/* TITLE */}
            <h2 className="text-orange-500 text-2xl font-bold mb-2">
              {item.title}
            </h2>

            {/* DESCRIPTION */}
            <p className="text-gray-800 text-sm leading-relaxed">
              {item.desc}
            </p>
          </div>
        ))}
      </div>

      {/* RAINBOW */}
      <img
        src={rainbow}
        alt="rainbow"
        className="absolute -bottom-20 left-1/2 -translate-x-1/2 w-[800px] md:w-[1200px] opacity-90"
      />

      {/* BOTTOM SEPARATOR (FULLY VISIBLE) */}
<img
  src={separator}
  alt="separator"
  className="absolute -bottom-6 md:-bottom-24 left-0 w-full h-auto z-20"
/>
    </div>
  );
};

export default Classes;