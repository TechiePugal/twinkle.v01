import React from "react";
import bg from "../assets/ORANGE-BGM.jpg";
import rainbow from "../assets/RAINBOW.png";
import rainbow2 from "../assets/RAINBOW.png";
import rainbow3 from "../assets/RAINBOW - Copy.png";
import flowerYellow from "../assets/YELLOW-CLOUD.png";
import flowerBlue from "../assets/blue-cloud-with-star.png";
import plane from "../assets/AERO1.png";
import star from "../assets/STAR.png";
import separator from "../assets/DWHITE-SEPERATOR.png";
import Abtpic from "../assets/about-us-image.png";
const About = () => {
  return (
    <div className="relative w-full overflow-hidden">

<img
  src={separator}
  alt="separator"
  className="w-full absolute -top-6 md:-top-16 left-0 z-20 pointer-events-none"
/>

      {/* BACKGROUND SECTION */}
      <div
        className="w-full min-h-screen flex items-center px-6 md:px-20 relative pt-32 md:pt-40"
        style={{
          backgroundImage: `url(${bg})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      >

        {/* RAINBOW LEFT */}
<img
  src={rainbow}
  alt=""
  className="rotate-180 absolute left-[-100px] top-[10px] w-[700px] opacity-90"
/>

{/* RAINBOW LEFT (rainbow2 → bottom left) */}
<img
  src={rainbow2}
  alt=""
  className=" rotate-90 absolute left-[-130px] bottom-[120px] w-[400px]"
/>

{/* RAINBOW RIGHT (rainbow3 → bottom right) */}
<img
  src={rainbow3}
  alt=""
  className="rotate-180 absolute right-[-80px] bottom-[-40px] w-[200px]"
/>

        {/* DECORATIONS */}
        <img
          src={flowerYellow}
          alt=""
          className="absolute bottom-10 right-40 w-36"
        />

        <img
          src={flowerBlue}
          alt=""
          className="absolute top-32 right-24 w-48"
        />

        <img
          src={plane}
          alt=""
          className="absolute bottom-10 left-[35%] w-52"
        />

        <img
          src={star}
          alt=""
          className="absolute top-14 left-[15%] w-20"
        />

        {/* CONTENT */}
        <div className="grid md:grid-cols-2 gap-10 items-center w-full z-10 mt-20 md:mt-32">

          {/* LEFT IMAGE */}
<div className="flex justify-center -mt-26 md:-mt-60">
  <img
    src={Abtpic}
    alt="kids"
    className="w-[350px] md:w-[450px] h-auto object-contain"
  />
</div>

          {/* RIGHT TEXT */}
         <div className="-mt-14 md:-mt-48 -ml-12 text-white max-w-xl text-justify">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              ABOUT US
            </h1>

            <p className="mb-4 text-base md:text-lg leading-relaxed">
              Twinkle Preschool is the leading kids school in Gobi with more
              than a decade of experience in the preschool industry. We believe
              every child is unique and full of potential. Our preschool
              provides a safe, happy, and nurturing environment where little
              minds grow through play, creativity, and exploration.
            </p>

            <p className="mb-4 text-base md:text-lg leading-relaxed">
              Our mission is to support the overall development of every child —
              socially, emotionally, physically, and academically. We focus on
              building strong foundations for lifelong learning.
            </p>

            <p className="text-base md:text-lg leading-relaxed">
              We provide a secure, clean, and child-friendly campus where
              children feel comfortable and confident. Safety and happiness are
              our top priorities.
            </p>
          </div>

        </div>
      </div>

      {/* BOTTOM SEPARATOR */}
      
    </div>
  );
};

export default About;