import Hero from "./components/Hero";
import Stats from "./components/About";
import Class from "./components/Class";

function App() {
  return (
    <>
      <Hero />
      <Stats />
      <Class />
    </>
  );
}

export default App;